// config/db.js
const mongoose = require('mongoose');

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log(`MongoDB Connected: ${conn.connection.host}`);
    
    // Crear roles iniciales si no existen
    await createInitialData();
  } catch (err) {
    console.error(`Error: ${err.message}`);
    process.exit(1);
  }
};

const createInitialData = async () => {
  const User = require('../models/User');
  // Verificar si existe un superadmin
  const superAdminExists = await User.findOne({ role: 'superadmin' });
  if (!superAdminExists) {
    const superAdmin = new User({
      username: 'superadmin',
      email: 'superadmin@example.com',
      password: 'Admin123!', // En producción, usa una contraseña más segura
      role: 'superadmin'
    });
    await superAdmin.save();
    console.log('Superadmin creado automáticamente');
  }
};

module.exports = connectDB;