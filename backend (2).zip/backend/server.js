require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
const morgan = require('morgan');
const cookieParser = require('cookie-parser');
const connectDB = require('./config/db');
const errorHandler = require('./middleware/errorMiddleware');

// Conexión a la base de datos
connectDB();

// Configuración de CORS
const corsOptions = {
  origin: [
    'http://localhost:3000',
    'https://paraisoverde.vercel.app',
    'https://www.paraisoverde.com'
  ],
  credentials: true,
  optionsSuccessStatus: 200
};

const app = express();

// Middlewares básicos
app.use(helmet());
app.use(cors(corsOptions));
app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

// Rutas
app.use('/api/users', require('./routes/user.Routes'));
app.use('/api/hotels', require('./routes/hotel.Routes'));
app.use('/api/sites', require('./routes/site.Routes'));

// Middleware de manejo de errores (DEBE SER EL ÚLTIMO)
app.use(errorHandler); // Asegúrate de que errorHandler sea una función válida

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en puerto ${PORT}`);
});