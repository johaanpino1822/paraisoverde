const express = require('express');
const { createHotel, getHotels } = require('../controllers/hotel.Controller');
const router = express.Router();

router.post('/', createHotel);
router.get('/', getHotels);

module.exports = router;
