const User = require('../models/User');
const Hotel = require('../models/Hotel');
const Site = require('../models/Site');
const asyncHandler = require('express-async-handler');

// @desc    Obtener estadísticas del dashboard
// @route   GET /api/admin/stats
// @access  Private/Admin
const getStats = asyncHandler(async (req, res) => {
  const [users, hotels, sites] = await Promise.all([
    User.countDocuments(),
    Hotel.countDocuments({ isActive: true }),
    Site.countDocuments({ isActive: true })
  ]);

  res.json({
    users,
    hotels,
    sites
  });
});

module.exports = {
  getStats
};