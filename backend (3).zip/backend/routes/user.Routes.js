const express = require('express');
const router = express.Router();

const {
  registerUser,
  loginUser,
  getUserProfile,
  updateUserProfile,
  getUsers,
  updateUser,
  deleteUser
} = require('../controllers/user.Controller');

const { protect, admin, superAdmin } = require('../middleware/authMiddleware');

// Rutas públicas
router.post('/register', registerUser);
router.post('/login', loginUser);

// Rutas protegidas
router.get('/profile', protect, getUserProfile);
router.put('/profile', protect, updateUserProfile);

// Rutas de administración
router.get('/', protect, admin, getUsers);
router.put('/:id', protect, superAdmin, updateUser);
router.delete('/:id', protect, superAdmin, deleteUser);

module.exports = router;
