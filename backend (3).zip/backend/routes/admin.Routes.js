const express = require('express');
const router = express.Router();
const { getStats } = require('../controllers/admin.controller');
const { protect, admin } = require('../middleware/authMiddleware');

router.route('/stats')
  .get(protect, admin, getStats);

module.exports = router;